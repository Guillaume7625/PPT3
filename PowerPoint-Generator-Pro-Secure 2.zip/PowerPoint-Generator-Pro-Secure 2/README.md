# PowerPoint Generator Pro - Consulting Edition

## 🚀 Installation & Utilisation

### ✅ Fichiers inclus
- `index.html` - L'application complète
- `pptxgen.bundle.js` - La bibliothèque PptxGenJS (REQUIS)
- `README.md` - Ce fichier d'instructions

### 📋 Comment utiliser

1. **Ouvrir l'application**
   - Double-cliquez sur `index.html` pour l'ouvrir dans votre navigateur
   - L'application fonctionne 100% hors ligne

2. **Vérifier le statut**
   - En haut de la page, vérifiez que le statut indique "Système prêt" ✅
   - Si vous voyez "Bibliothèque manquante" ❌, assurez-vous que `pptxgen.bundle.js` est dans le même dossier

3. **Générer une présentation**

   **Étape 1:** Cliquez sur "📋 Copier le prompt" pour copier le template
   
   **Étape 2:** Collez ce prompt dans votre IA préférée (ChatGPT, Claude, Gemini, etc.)
   
   **Étape 3:** Personnalisez le contexte dans le prompt :
   ```
   SUJET : [ex: Stratégie Marketing 2024]
   NOMBRE_SLIDES : [ex: 10 ou AUTO]
   STYLE : [professionnel|créatif|académique|commercial]
   ```
   
   **Étape 4:** L'IA vous retournera un JSON. Copiez-le entièrement.
   
   **Étape 5:** Collez le JSON dans le champ de droite de l'application
   
   **Étape 6:** Cliquez sur le bouton bleu "▶ Générer PowerPoint" en haut de la page

### 🎨 Design professionnel

Cette version utilise un design inspiré des cabinets de conseil (McKinsey, BCG, Deloitte) avec :
- Palette de couleurs professionnelle (bleu corporate)
- Mise en page claire et épurée
- Typographie moderne et lisible
- Tableaux alternés pour une meilleure lisibilité
- Graphiques aux couleurs cohérentes

### 💡 Conseils

- **Pour de meilleurs résultats**, donnez un maximum de contexte à l'IA
- **Vérifiez le JSON** avant de générer (pas de virgules finales, guillemets corrects)
- **Les images** sont remplacées par des placeholders descriptifs
- **Personnalisez** le nom du fichier dans metadata.fileName

### 🔧 Dépannage

**Problème : "Bibliothèque manquante"**
→ Solution : Assurez-vous que `pptxgen.bundle.js` est dans le même dossier que `index.html`

**Problème : "JSON invalide"**
→ Solution : Vérifiez que le JSON est complet, sans caractères spéciaux non échappés

**Problème : Le bouton ne fonctionne pas**
→ Solution : Ouvrez la console du navigateur (F12) pour voir les erreurs détaillées

### 📦 Structure des dossiers

```
powerpoint-generator-pro/
│
├── index.html           # Application principale
├── pptxgen.bundle.js    # Bibliothèque (OBLIGATOIRE)
└── README.md           # Instructions
```

### 🌐 Compatibilité

- ✅ Chrome (recommandé)
- ✅ Edge
- ✅ Firefox
- ✅ Safari
- ✅ Fonctionne 100% hors ligne
- ✅ Aucune installation requise

### 📝 Exemple de JSON

```json
{
  "metadata": {
    "title": "Stratégie Digitale 2024",
    "fileName": "strategie-digitale-2024.pptx",
    "author": "John Doe"
  },
  "slides": [
    {
      "type": "title",
      "title": "Stratégie Digitale 2024",
      "subtitle": "Transformation et Innovation"
    },
    {
      "type": "content",
      "title": "Objectifs Principaux",
      "bullets": [
        "Augmenter la présence digitale de 40%",
        "Implémenter 3 nouvelles technologies",
        "Former 100% des équipes"
      ]
    }
  ]
}
```

---
**Version:** 1.0 Consulting Edition  
**Support:** PowerPoint Generator Pro
# 🔒 PowerPoint Generator Pro - Versions Disponibles

## 📦 Fichiers dans ce dossier

### 1. `index.html` - Version Consulting Standard
- Design professionnel style cabinet de conseil
- Interface moderne et épurée
- Fonctionne 100% hors ligne

### 2. `index-secure.html` - Version Ultra-Sécurisée ⭐
- **RECOMMANDÉE** pour une sécurité maximale
- Inclut une **Content Security Policy (CSP) stricte**
- Bloque TOUTE connexion Internet (`connect-src 'none'`)
- Garantit que vos données restent 100% privées
- Validation JSON en temps réel
- Sanitisation automatique des entrées
- Protection contre les injections XSS

### 3. `pptxgen.bundle.js` - Bibliothèque requise
- Nécessaire pour les deux versions
- Doit être dans le même dossier que les fichiers HTML

## 🛡️ Différences de sécurité

### Version Secure (`index-secure.html`)
```
✅ Content Security Policy activée
✅ Aucune connexion externe possible
✅ Validation stricte des données
✅ Sanitisation des entrées utilisateur
✅ Protection contre l'injection de code
✅ Indicateur de sécurité visible
✅ Validation JSON en temps réel
```

### Version Standard (`index.html`)
```
✓ Fonctionne hors ligne
✓ Design professionnel
✓ Validation basique
```

## 🚀 Utilisation recommandée

### Pour une sécurité maximale :
1. Utilisez **`index-secure.html`**
2. Vérifiez le badge "🔒 100% Offline & Sécurisé" en haut
3. Le statut de validation JSON s'affiche en temps réel

### Comment démarrer :
```bash
# Ouvrir directement dans le navigateur
open index-secure.html

# Ou double-cliquez sur le fichier
```

## 🔐 Garanties de sécurité

La version sécurisée garantit :
- **Aucune fuite de données** : CSP bloque toute connexion externe
- **Pas de tracking** : Aucune télémétrie ou analytics
- **Confidentialité totale** : Vos présentations restent sur votre machine
- **Protection XSS** : Sanitisation automatique de toutes les entrées

## 📝 Exemple de CSP appliquée

```html
<meta http-equiv="Content-Security-Policy"
  content="default-src 'self' data: blob:; 
           img-src 'self' data: blob:; 
           style-src 'self' 'unsafe-inline'; 
           script-src 'self' 'unsafe-inline'; 
           connect-src 'none';">
```

Cette politique :
- `connect-src 'none'` : Bloque TOUTE connexion réseau
- `script-src 'self'` : Autorise uniquement les scripts locaux
- `default-src 'self'` : Restreint toutes les ressources aux fichiers locaux

## ⚡ Performance

Les deux versions ont les mêmes performances :
- Génération instantanée des PowerPoint
- Support de tous les types de slides
- Compatible avec tous les navigateurs modernes

## 💡 Conseil

**Utilisez `index-secure.html` pour tous vos besoins professionnels.**
Cette version offre le même confort d'utilisation avec une sécurité renforcée.

---
Version : 2.0 Secure Edition
Date : Octobre 2024